public class Process {
    public String Name;
    public int Size;
    public Process(String name,int size){
        Name=name;
        Size=size;
    }
}
