import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class BestFit {
    Scanner Input;

    public BestFit(Scanner input) {
        Input = input;
    }

    public LinkedList<String> Execute(
            LinkedList<Process> processes,
            LinkedList<Partition> partitions,
            boolean shouldAskToCompact) {
        LinkedList<String> operations = new LinkedList<>();

        LinkedList<Partition> allocatedPartitions = new LinkedList<>();

        LinkedList<Process> allocatedProcesses = new LinkedList<>();


        for (int processIndex = 0; processIndex < processes.size(); processIndex++) {
            Process process = processes.get(processIndex);

            int bestFitPartitionIndex=-1;

            for (int partitionIndex = 0; partitionIndex < partitions.size(); partitionIndex++) {
                Partition partition = partitions.get(partitionIndex);

                if (partition.Size >= process.Size) {
                    if(bestFitPartitionIndex==-1){
                        bestFitPartitionIndex=partitionIndex;
                    } else if (partitions.get(bestFitPartitionIndex).Size > partition.Size){
                        bestFitPartitionIndex=partitionIndex;
                    }
                }
            }

            if(bestFitPartitionIndex!=-1){
                allocatedProcesses.add(process);

               Partition bestFitPartition=partitions.get(bestFitPartitionIndex);

                int remainingSize = bestFitPartition.RemoveProcessSizeAndGetRemaining(process.Size);

                operations.add(bestFitPartition.toString() + "=>" + process.Name);

                allocatedPartitions.add(bestFitPartition);

                if (remainingSize > 0) {
                    Partition newPartition = new Partition(partitions.size(), remainingSize);

                    int newPartitionIndex = bestFitPartitionIndex + 1;

                    partitions.add(newPartitionIndex, newPartition);
                }
            }
        }

        List<Process> unAllocatedProcesses = processes.stream().filter(p -> allocatedProcesses.contains(p) == false).collect(Collectors.toList());

        for (int i = 0; i < unAllocatedProcesses.size(); i++) {
            operations.add(unAllocatedProcesses.get(i).Name + " can not be allocated");
        }

        List<Partition> unAllocatedPartitions = partitions.stream().filter(p -> allocatedPartitions.contains(p) == false).collect(Collectors.toList());

        for (int i = 0; i < unAllocatedPartitions.size(); i++) {
            operations.add(unAllocatedPartitions.get(i).toString() + "=> External fragment");
        }


        for (int i = 0; i < operations.size(); i++) {
            System.out.println(operations.get(i));
        }

        if (shouldAskToCompact) {
            System.out.println();
            System.out.println("Do you want to compact? 1.yes 2.no ");

            int answer = Input.nextInt();

            if (answer == 1) {


                int compactedPartitionSize = unAllocatedPartitions.stream().mapToInt(p -> p.Size).sum();

                Partition compactedPartition = new Partition(partitions.size(), compactedPartitionSize);

                LinkedList<Partition> allocatedPartitionsFromPreviousRun = new LinkedList(partitions.stream().filter(p -> allocatedPartitions.contains(p)).collect(Collectors.toList()));

                allocatedPartitionsFromPreviousRun.add(compactedPartition);

                Execute(processes, allocatedPartitionsFromPreviousRun, false);
                System.out.println();
            }
        }

        return operations;
    }
}
