import java.util.LinkedList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter number of partitions");

        int partitionSize = input.nextInt();

        LinkedList<Partition> partitions = new LinkedList<>();

        for (int i = 0; i < partitionSize; i++) {
            System.out.println("Partition name");
            String name = input.next();
            System.out.println("Partition size");
            int size = input.nextInt();
            partitions.add(new Partition(name, size));
        }

        LinkedList<Process> processes = new LinkedList<Process>();
        System.out.println();

        System.out.println("Enter number of processes");

        int processSize = input.nextInt();

        for (int i = 0; i < processSize; i++) {
            System.out.println("Process name");
            String name = input.next();
            System.out.println("Process size");
            int size = input.nextInt();
            processes.add(new Process(name, size));
        }

//        LinkedList<Process> processes = new LinkedList<Process>();
//        processes.add(new Process("P1",15));
//        processes.add(new Process("P2",90));
//        processes.add(new Process("P3",30));
//        processes.add(new Process("P4",100));
//        LinkedList<Partition> partitions = new LinkedList<>();
//
//        partitions.add(new Partition(0,90));
//        partitions.add(new Partition(1,20));
//        partitions.add(new Partition(2,5));
//        partitions.add(new Partition(3,30));
//        partitions.add(new Partition(4,120));
//        partitions.add(new Partition(5,80));

        System.out.println();
        System.out.println("Select the policy you want to apply:");
        System.out.println("1. First fit");
        System.out.println("2. Best fit");
        System.out.println("3. Worst fit");

        int policy = input.nextInt();

        System.out.println();
        if (policy == 1) {
            new FirstFit(input).Execute(processes, partitions, true);
        } else if (policy==2) {
            new BestFit(input).Execute(processes, partitions, true);
        } else if (policy==3) {
            new WorstFit(input).Execute(processes, partitions, true);
        } else {
            System.out.println("Unknown");
        }
    }
}