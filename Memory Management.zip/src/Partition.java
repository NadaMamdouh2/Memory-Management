public class Partition {
    public String Name;

    public int Size;

    public Partition(int index,int size){
        Name="Partition "+index;
        Size=size;
    }

    public Partition(String name,int size){
        Name=name;
        Size=size;
    }

    public int RemoveProcessSizeAndGetRemaining(int processSize){
        int remainingSize= Size-processSize;
        Size=processSize;
        return remainingSize;
    }

    @Override
    public String toString() {
        return Name+" "+"("+ Size +"KB)";
    }
}
